Place executable scripts in each directory to run a hook at the end of a docker-entrypoint.sh script.

Only images with a docker-entrypoint are covered.
