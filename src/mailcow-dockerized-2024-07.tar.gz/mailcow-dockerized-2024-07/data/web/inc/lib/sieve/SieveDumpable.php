<?php namespace Sieve;

interface SieveDumpable
{
	function dump();
	function text();
}
